<!DOCTYPE html>

<html>
<head>
  <title>TD2 - Exercice 1</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <style>.err {font-weight: bold;}</style>
</head>

<body>

<?php
  // Pour forcer l'affichage des erreurs
  //
  ini_set('display_errors', '1');
  error_reporting(E_ALL);

  // Connexion à la base
  //
  $cnx = mysqli_connect('localhost', 'root', 'root', 'base');
  if (!$cnx) die("<p class=\"err\">Erreur de connexion à la base</p>");

  // Création de la table si elle n'existe pas déjà
  //
  mysqli_query($cnx, "CREATE TABLE IF NOT EXISTS membre (id INT AUTO_INCREMENT, nom VARCHAR(255), prenom VARCHAR(255), email VARCHAR(255), ville VARCHAR(255), PRIMARY KEY(id))") or die("<p class=\"err\">Erreur de création de table</p>");

  // Variables utilisées pour le maintien du formulaire
  //
  $nom = ""; $prenom = ""; $email = ""; $ville = "";

  // Inscription de l'internaute si formulaire validé
  //
  if (isset($_POST['ch_bouton'])) {
    $nom = $_POST['ch_nom'];
    $prenom = $_POST['ch_prenom'];
    $email = $_POST['ch_email'];
    $ville = $_POST['ch_ville'];

    // Test : formulaire complet ?
    //
    if (empty($nom) || empty($prenom) || empty($email) || empty($ville)) {
      echo "<p>Formulaire incomplet : merci de renseigner tous les champs</p>";
    // Test : adresse email bien formée ?
    //
    } else if (!preg_match('/^[a-z0-9._-]{2,128}@([a-z0-9_-]{2,64}\.){1,4}[a-z]{2,6}$/', $email)) {
      echo "<p>Adresse e-mail incorrecte</p>";
    } else {
      // Test : e-mail (ou fiche complète) déjà présent(e) dans la BDD ?
      //
      $res = mysqli_query($cnx, "SELECT * FROM membre WHERE email = '$email'");
      if (mysqli_num_rows($res) == 1) {
        $tMembre = mysqli_fetch_assoc($res);
        if ($tMembre['nom'] == $nom && $tMembre['prenom'] == $prenom && $tMembre['ville'] == $ville) {
          echo "<p>Vous êtes déjà inscrit-e dans notre base de données</p>";
        } else {
          echo "<p>Cette adresse e-mail est déjà présente dans la base de données</p>";
        }
      } else {
        // Insertion de la fiche dans la BDD
        //
        mysqli_query($cnx, "INSERT INTO membre (nom, prenom, email, ville) VALUES ('$nom', '$prenom', '$email', '$ville')") or die("<p class=\"err\">Erreur d'insertion dans la table</p>");
      }
    }
  }

?>

<!-- Affichage du formulaire (avec insertions PHP pour le maintien des champs) -->

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
  <p><label for="ch_nom">Nom</label> <input type="text" name="ch_nom" id="ch_nom" value="<?php echo $nom; ?>" /></p>
  <p><label for="ch_prenom">Prénom</label> <input type="text" name="ch_prenom" id="ch_prenom" value="<?php echo $prenom; ?>" /></p>
  <p><label for="ch_email">E-mail</label> <input type="text" name="ch_email" id="ch_email" value="<?php echo $email; ?>" /></p>
  <p><label for="ch_ville">Ville</label> <input type="text" name="ch_ville" id="ch_ville" value="<?php echo $ville; ?>" /></p>
  <p><input type="submit" name="ch_bouton" value="INSCRIPTION" /></p>
</form>

<?php

  // Affichage de la table des inscrits
  //
  echo '<table border="1"><tr><td>ID</td><td>Nom</td><td>Prénom</td><td>E-mail</td><td>Ville</td></tr>'; // On ouvre la table HTML
  $res = mysqli_query($cnx, "SELECT * FROM membre"); // On réalise l'extraction MySQL
  $l = mysqli_fetch_row($res); // On récupère la première ligne extraite
  while ($l) { // Tant que la ligne courante est non vide (on n'a pas atteint la fin des données extraites)
    echo "<tr>"; // On ouvre une nouvelle ligne dans la table HTML
    for ($i = 0; $i < count($l); $i++) {
      echo "<td>$l[$i]</td>"; // On affiche chaque champ dans une cellule de la ligne
    }
    echo "</tr>"; // On ferme la ligne
    $l = mysqli_fetch_row($res); // Puis on passe à la ligne suivante
  }
  echo '</table>'; // On referme la table HTML
?>

</body>
</html>

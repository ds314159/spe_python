function fCalculeCle(sMot) { // Nettoie le mot et ordonne ses lettres
    const aCar = sMot.toLowerCase().replace(/[^a-zàâäçéèêëîïôöùûüÿ]/ig, "").split("");
	const dTable = {'à':'a', 'â':'a', 'ä':'a', 'ç':'c', 'é':'e', 'è':'e', 'ê':'e', 'ë':'e', 'î':'i', 'ï':'i', 'ô':'o', 'ö':'o', 'ù':'u', 'û':'u', 'ü':'u', 'ÿ':'y'};
    for (let i = 0; i < aCar.length; i++)
		if (aCar[i] in dTable) aCar[i] = dTable[aCar[i]];
    return aCar.sort().join("");
}

function fPrepareDict() { // Création du dictionnaire d'anagrammes à partir du lexique fourni
    const dDict = {};
    for (let i = 0; i < aLexique.length; i++) {
        const sMot = aLexique[i];
        const sCle = fCalculeCle(sMot);
        if (sCle in dDict) dDict[sCle].push(sMot);
        else dDict[sCle] = [sMot];
    }
    return dDict;
}

function fAnagrammesSimples(sCle, dDict) { // Recherche d'anagrammes simples (en un mot)
    if (sCle in dDict) alert("Anagrammes simples trouvées: " + dDict[sCle].join('/'));
    else alert("Aucune anagramme simple pour vos lettres");
}

function fIncluse(s1, s2) { // Teste si s1 est incluse dans s2 et retourne le résidu de s2
    let n1 = 0
    let n2 = 0
    let sDiff2 = "";
    while (n1 < s1.length && n2 < s2.length) { // L'algo repose sur le fait que les chaînes s1 et S2 sont ordonnées
        if (s1.charAt(n1) == s2.charAt(n2)) {
            n1++;
            n2++;
        } else if (s1.charAt(n1) > s2.charAt(n2)) {
            sDiff2 += s2.charAt(n2);
            n2++;
        } else return [false, ''];
    }
    if (n1 < s1.length) return [false, ''];
    while (n2 < s2.length) {
        sDiff2 += s2.charAt(n2);
        n2++;
    }
    return [true, sDiff2];
}

function fAnagrammesDoubles(sCle, dDict) { // Recherche d'anagrammes en deux mots
    let sRes = "";
    let nAna = 0;
    for (const sC in dDict) {
        const aInfo = fIncluse(sC, sCle);
        if (aInfo[0] && aInfo[1] in dDict && sC < aInfo[1]) {
            nAna++;
            sRes += dDict[sC].join('/') + ' ' + dDict[aInfo[1]].join('/') + '\n';
        }
    }
    if (sRes == "") alert("Aucune anagramme double pour vos lettres");
    else alert(nAna + " anagrammes doubles trouvées:\n" + sRes);
}

// Pourquoi choisir JS plutôt que PHP pour réaliser la recherche d'anagrammes :
// L'intérêt de faire travailler JS, c-à-d l'ordinateur de l'internaute, plutôt que PHP,
// c-à-d le serveur, c'est de décharger ce dernier. En effet, suivant le nombre de
// lettres fixées, la taille du dictionnaire, et le nombre de mots autorisés (ici, on
// cherche les anagrammes sur 1 mot ou sur 2 mots, mais on pourrait généraliser la
// méthode à n mots), cette recherche peut s'avérer relativement coûteuse en mémoire et
// en CPU. Et ce coût sera bien sûr multiplié par le nombre d'internautes connectés
// simultanément. Dans ce genre de situation, il est préférable de reporter la charge
// sur le client.
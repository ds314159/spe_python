<html>
<head>
	<title>TD2 - Exercice 2a</title>
	<meta http-equiv="Content-Type" content="text/html;charset=utf8" />
</head>
<body>
  <h1>TD 2 - Exercice 2a</h1>
<?php
  ini_set('display_errors', '1'); // Pour forcer l'affichage des erreurs
  error_reporting(E_ALL);
?>

  <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
    <p><label for="ch_lettres">Vos lettres</label> <input type="text" name="ch_lettres" id="ch_lettres" autofocus="true" /></p>
    <p><input type="submit" name="ch_bouton" value="ANAGRAMMES" /></p>
  </form>

<?php
  if (isset($_POST['ch_bouton']) && !empty($_POST['ch_lettres'])) {
  	echo '<script type="text/javascript" src="ex2_dict.js"></script>';
	  echo '<script type="text/javascript" src="ex2.js"></script>';
	  echo '<script type="text/javascript">const sLettres="' . $_POST['ch_lettres'] . '";</script>'; // On transmet la saisie utilisateur de PHP vers JS
	  echo '<script type="text/javascript" src="ex2a.js"></script>';                                 // Puis on lance le script côté client
  }
?>
</body>
</html>

// Version PHP-JS : la variable sLettres a été créée dynamiquement en PHP
//
// Programme  principal
//
const dDict = fPrepareDict();
const sCle = fCalculeCle(sLettres);
fAnagrammesSimples(sCle, dDict);
fAnagrammesDoubles(sCle, dDict);

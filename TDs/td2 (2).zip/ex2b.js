// Version "full JS"
//
function fEntree() { // Entrée utilisateur et retour de la clé correspondante
    const sIn = prompt("Vos lettres :");
    return fCalculeCle(sIn);
}

// Programme  principal
//
const dDict = fPrepareDict(); // Création du dictionnaire
while (true) {                // Boucle principale
    const sCle = fEntree();
    if (sCle == "") break;
    fAnagrammesSimples(sCle, dDict);
    fAnagrammesDoubles(sCle, dDict);
}
